# PRO_C118_PP_V1
IMPLEMENTACIÓN DE APLICACIÓN WEB: Diario digital  
Python. Flask. jQuery.  
  
Análisis de sentimiento  
  
### Texto en inglés: PRO-C118-Project-Boilerplate
